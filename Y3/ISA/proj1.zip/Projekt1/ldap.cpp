#include "ldap.h"

void LDAP::respond(){
    uint8_t* answer = this->response->messVector.data();
    send(this->socket,answer,this->response->getLength()+2,0);
}

void LDAP::process(string path){
    LDAPProtocolOp* response = this->request->protocolOp->processProtocolOp(path);
    this->response = new LDAPMessage(response,this->request->getID(),this->request->getIDLength());
}

void LDAP::receive(){
    uint8_t buffer[BUF_SIZE];
    int n = 0;
    int length;

    // Receives request
    memset(buffer,0,BUF_SIZE);

    n = recv(this->socket, buffer, 1, 0);
    if(n == 1 && int(buffer[0]) == MESSAGE_TYPE){
        n = recv(this->socket, buffer, 1, 0);
        length = int(buffer[0]);
        n = recv(this->socket, buffer, length, 0);
        if(n == length){
            this->request = new LDAPMessage(length,buffer);
            try{
                this->request->parseMessage();
            }
            catch (exception& e){
                cout << e.what() << '\n';
            }
        }
    }
}



/**
* Communicates with the client specified in "acc_soc" socket. Firstly it parses
* the given request and sends response to this request to this client. 
*
* @param	acc_soc		socket for
* @param	path		received socket address
*
* @return	ERROR in case of error, else 0  
*/
int LDAP::communicate(int acc_soc,string path){
    this->socket = acc_soc;
    int count = 0;
    while(1){
        if(count == 2)
            break;
        this->receive();
        this->process(path);	
        this->respond();
        count++;
    }
    return 0;
}
