#include "ldapop.h"


int LDAPProtocolOp::getLength(){
	return this->length;
}

void LDAPProtocolOp::appendVector(uint8_t c){
	this->messVector.push_back(c);
	this->length++;
}

void LDAPProtocolOp::getMessage(uint8_t*& message,int& len){
	message = this->message;
	len = this->length;
}

int LDAPProtocolOp::getType(){
	return this->type;
}

LDAPProtocolOp::LDAPProtocolOp(){
	this->length = 0;
	this->message = NULL;
}

LDAPProtocolOp::LDAPProtocolOp(int length, uint8_t* message, int type){
	this->length = length;
	this->message = new uint8_t[length];
	memcpy(this->message,message,length);
	this->type = (operation_t) type;
	this->reqStruct = new LDAPProtocolOp::req;
	this->reqStruct->filter = new stack<fItem>;
}


LDAPProtocolOp* LDAPProtocolOp::processProtocolOp(string path){
	LDAPProtocolOp* tmp = new LDAPProtocolOp();
	switch (this->type){
		case BIND_REQUEST:
			tmp->appendVector(10);
			tmp->appendVector(1);
			tmp->appendVector(0);
			tmp->appendVector(4);
			tmp->appendVector(0);
			tmp->appendVector(4);
			tmp->appendVector(0);

			tmp->type = BIND_RESPONSE;
			return tmp;
		case SEARCH_REQUEST:
			while (!this->reqStruct->filter->empty()){
				switch(this->reqStruct->filter->top().type){
					case EQ:
						cout << "EQ" << endl;
						break;
					case SUB:
						cout << "SUB" << endl;
						break;
					case AND:
						cout << "AND" << endl;
						break;
					case OR:
						cout << "OR" << endl;
						break;
					case NOT:
						cout << "NOT" << endl;
						break;
					default:
						break;
				}
				this->reqStruct->filter->pop();
			}
		default:
			return NULL;
	}
}

void LDAPProtocolOp::parseBindRequest(){
	if(int(this->message[0]) == 2){
		int versionLen = int(this->message[1]);
		if(versionLen == 1){
			this->version = int(this->message[2]);
			if(int(this->message[3]) == 4){
				int len = int(this->message[4]);
				if(int(message[5+len]) == -128){	//simple authen
					int passLen = int(message[len+6]);	// password length
					this->password = new char[passLen];
					memcpy(this->password,this->message+7+len,passLen);
				}
			}
		}
	}
}

bool LDAPProtocolOp::parseString(string& str){
	uint8_t item = this->message[this->index];
	printf("%x\n",item);
	if(item == 0x04){
		cout << "string" << endl;
		this->incrementIndex();
		this->createString(str);
		return true;
	}
	return false;
}

void LDAPProtocolOp::createString(string& s){
	int length = int(this->message[this->index]);
	this->incrementIndex();
	char* str = new char[length+1];
	memset(str,0,(length+1)*sizeof(char));
	memcpy(str,this->message+this->index,length*sizeof(uint8_t));
	s = string(str);
	cout << length << s << endl;
	this->incrementIndex(length);
}


// TODO: rekurzia
bool LDAPProtocolOp::parseSubString(string& str){
	uint8_t item = this->message[this->index];
	printf("%x\n",item);
	string tmp;
	switch (item){
		case 0x80:
			cout << "initial" << endl;
			this->incrementIndex();
			this->createString(tmp);
			this->substr += tmp + string("*");
			cout << this->substr << endl;
			break;
		case 0x81:
			cout << "any" << endl;
			this->incrementIndex();
			this->createString(tmp);
			this->substr += string("*") + tmp + string("*");
			cout << this->substr << endl;
			break;
		case 0x82:
			cout << "final" << endl;
			this->incrementIndex();
			this->createString(tmp);
			this->substr += string("*") + tmp;
			cout << this->substr << endl;
			break;
		default:
			str = this->substr;
			return true;
			break;
	}
	return this->parseSubString(str);
}


bool LDAPProtocolOp::parseFilter(){
	uint8_t size;
	uint8_t item;
	int length;
	string key;
	string val;
	string substr;
	LDAPProtocolOp::fItem *filterItem = new LDAPProtocolOp::fItem;
	switch (this->message[this->index]){
		case AND:
			cout << "AND" << endl;
			this->incrementIndex();
			size = this->message[this->index];
			this->incrementIndex();
			filterItem->type = AND;
			this->reqStruct->filter->push(*filterItem);
			break;
		case OR:
			cout << "OR" << endl;
			this->incrementIndex();
			size = this->message[this->index];
			this->incrementIndex();
			filterItem->type = AND;
			this->reqStruct->filter->push(*filterItem);
			break;
		case EQ:
			cout << "EQ" << endl;
			this->incrementIndex();
			size = this->message[this->index];
			this->incrementIndex();
			if(this->parseString(key)){
				if(this->parseString(val)){
					filterItem->type = EQ;
					filterItem->leftOp= key;
					filterItem->rightOp= val;
					this->reqStruct->filter->push(*filterItem);
					break;
				}
			}
			return false;
		case SUB:
			cout << "SUB" << endl;
			this->incrementIndex();
			size = this->message[this->index];
			this->incrementIndex();
			if(this->parseString(key)){
				if(this->message[this->index] == 0x30){
					this->incrementIndex();
					cout << "here" << endl;
					uint8_t size2 = this->message[this->index];
					this->incrementIndex();
					this->substr = string();
					if(this->parseSubString(substr)){
						filterItem->type = SUB;
						filterItem->leftOp= key;
						filterItem->rightOp= substr;
						this->reqStruct->filter->push(*filterItem);
						break;
					}
				}
			}
			break;
		case NOT:
			cout << "NOT" << endl;
			this->incrementIndex();
			size = this->message[this->index];
			this->incrementIndex();
			filterItem->type = NOT;
			this->reqStruct->filter->push(*filterItem);
			break;
		default:
			return true;
			break;
	}
	return this->parseFilter();
}

bool LDAPProtocolOp::parseInt(uint32_t &item){
	this->incrementIndex();
	int idLen = int(this->message[this->index]);
	if(idLen >= 1 && idLen <= 4){
		// Allocates space for 32bit int
		uint8_t* id = new uint8_t[sizeof(uint32_t)];
		memset(id,0,sizeof(uint32_t)*sizeof(uint8_t));
		
		this->incrementIndex();
		int j;
		for(j = 0; j < idLen; j++){
			id[j] = this->message[this->index+idLen-j-1];
		}
		this->incrementIndex(j-1);
		item = * (uint32_t*) id;
		cout << "Size: " << item << " len: " << idLen << " index: " << this->index << " next-item: " << int(this->message[this->index+1]) << endl;
		
		return true;

	}
	return false;
}

void LDAPProtocolOp::incrementIndex(){
	if(this->index < this->length - 1){
		this->index++;
	}
	else{
		throw myex;
	}
}

void LDAPProtocolOp::incrementIndex(int x){
	if(this->index < this->length - x){
		this->index += x;
	}
	else{
		throw myex;
	}
}

void LDAPProtocolOp::parseSearchRequest(){
	state_t state = START;
	int length = 0;
	for(this->index = 0; this->index < this->length; this->index++){
		uint8_t byte = this->message[this->index];
		switch(state){
			case START:
				if(byte == 0x04){
					this->incrementIndex();
					byte = this->message[this->index];
					if(byte != 0){
						this->incrementIndex(int(byte));
					}
					state = SCOPE;
					break;
				}
				return;
			case SCOPE:
				if(byte == 0x0A){
					this->incrementIndex();
					byte = this->message[this->index];
					if(byte == 0x01){
						this->incrementIndex();
						byte = this->message[this->index];
						if(byte == 0){
							state = DEREF;
							break;
						}
					} 
				}
				return;
			case DEREF:
				if(byte == 0x0A){
					this->incrementIndex();
					byte = this->message[this->index];
					if(byte != 0){
						this->incrementIndex(int(byte));
					}
					state = SIZE;
					break;
				}				
				return;
			case SIZE:
				if(byte == 0x02){
					if(this->parseInt(this->reqStruct->size)){
						cout << "SIZE:" << this->reqStruct->size << " next-item: " << int(this->message[this->index]) << endl;
						state = TIME;
						break;
					}
				}				
				return;
			case TIME:
				cout << int(byte) << endl;
				if(byte == 0x02){
					if(this->parseInt(this->reqStruct->time)){
						cout << "TIME:" << this->reqStruct->time << endl;
						state = TYPES;
						break;
					}
				}
				return;
			case TYPES:
				if(byte == 0x01){
					this->incrementIndex();
					byte = this->message[this->index];
					if(byte == 0x01){
						this->incrementIndex();
						state = FILTER;
						break;
					}
				}
				return;
			case FILTER:
				if(this->parseFilter()){
					cout << "Filter processed" << endl;
				}
				return;
			default:
				break;
		}
	}
	
}

void LDAPProtocolOp::parseRequest(){
	switch (this->type){
		case BIND_REQUEST:
			this->parseBindRequest();		
			break;
        case SEARCH_REQUEST:
            this->parseSearchRequest();
			break;
		default:
			break;
	}
}
