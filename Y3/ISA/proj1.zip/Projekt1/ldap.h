#ifndef __LDAP_H_INCLUDED__
#define __LDAP_H_INCLUDED__

#include "ldapmessage.h"
#include <sys/types.h>
#include <sys/socket.h>


#define BUF_SIZE (2048)

class LDAP {
    private:
        int socket;
        LDAPMessage* request;
        LDAPMessage* response;
    public:
        int communicate(int, string);
        void respond();
        void receive();
        void process(string);
};
#endif
