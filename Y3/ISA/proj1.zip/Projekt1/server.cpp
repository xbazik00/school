/**
 * Server for HTTP protocol using RESTful API.
 * IPK Project 1
 *
 * @file server.cpp
 * @brief Server for file transfer application.
 *
 * @author Martin Bazik
 * @version 1.0 14/10/17
 */

#include <netinet/in.h>
#include <sys/stat.h>
#include <unistd.h>
#include "ldap.h"



#define ERROR (-1)
#define MAX_PATH (1024)


#define NUMBER_CLIENTS (5)
#define DEFAULT_PORT (389)
#define MIN_PORT (0)
#define MAX_PORT (65535)
//#define TIME_BUF (80)


using namespace std;

/**
 * Establishes connection with client.
 *
 * @param	port	port to connect
 * @param	soc	returns socket used
 * @param	server	returns received socket address
 *
 * @return	ERROR in case of error, else 0  
 */
int establish_connection(int port, int *soc, struct sockaddr_in *server){
	memset(server,0,sizeof(*server));

	if((*soc = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP/*0*/)) < 0){
		return ERROR;
	}

	server->sin_family = AF_INET;
	server->sin_port = htons(port);
	server->sin_addr.s_addr = INADDR_ANY;

	if(bind(*soc, (struct sockaddr *)server, sizeof(*server)) < 0){
		return ERROR;
	}

	if(listen(*soc, NUMBER_CLIENTS)){
		return ERROR;
	}
	return 0;
}

/**
 * Main function 
 *
 */
int main(int argc, char* argv[]){
	string csv_path;
	string str_port = string();
	struct stat file_stat;
	
	int c;
	int port = DEFAULT_PORT;
	size_t p = 0;
	bool file_used = false;

	// Parsing parameters using getopt
	while ((c = getopt (argc, argv, "p:f:")) != -1){
		switch (c){
			case 'f':
				csv_path = string(optarg);
				if (!(stat(csv_path.c_str(), &file_stat) == 0 && S_ISREG(file_stat.st_mode))){
					cerr << "Invalid CSV file path." << endl;
					return 1;
				}
				file_used = true;
				break;
			case 'p':
				str_port = string(optarg);
				p = 0;
				try{
					port = stol(str_port,&p,10);
					if(p != str_port.length()){
						cerr << "Port is not a number." << endl;
						return 1;
					}
				}
				catch (exception& e){
					cerr << "Invalid port number." << endl;
					return 1;
				}
				if(port < MIN_PORT || port > MAX_PORT){
					cerr << "Port is not within available ports." << endl;
					return 1;
				}
				break;
			default:
				cerr << "Unexpected parameters" << endl;
				exit(1);
		}
	}
	if(!file_used){
		cerr << "Parameter -f is not used!" << endl;
		exit(1);
	}

	// socket variables
	struct sockaddr_in server;
	struct sockaddr_in client;
	int socket;
	socklen_t soc_len;
	int acc_soc;


	// starts connection
	if(establish_connection(port,&socket,&server) == ERROR){
		return 1;
	}

	soc_len = sizeof(client);
	
	// Infinite loop to keep server running
	while (1){
		// Accepts incoming socket
		if((acc_soc = accept(socket, (struct sockaddr *) &client, &soc_len)) < 0){
			return 1;
		}		

		pid_t pid = fork();
		if(pid == 0){
			LDAP ldap;
			// Chat initialised
			if(ldap.communicate(acc_soc,csv_path) == ERROR){
				return 1;
			}
			break;
		}

		// Error while forking
		else if(pid < 0){
			cerr << "Error: Could not create process." << endl;
			return 1;
		}
		
	}
	close(socket);
	return 0;
}
