#include "ldapmessage.h"

int LDAPMessage::getLength(){
    return this->length;
}

uint32_t LDAPMessage::getID(){
    return this->messageID;
}

int LDAPMessage::getIDLength(){
    return this->IDLen;
}

void LDAPMessage::appendVector(uint8_t c){
    this->messVector.push_back(c);
}

void LDAPMessage::appendVector(vector<uint8_t> v){
    for(unsigned int i = 0; i < v.size(); i++){
        this->messVector.push_back(v[i]);
    }
}


LDAPMessage::LDAPMessage(int length, uint8_t* message){
    this->length = length;
    this->message = new uint8_t[length];
    memcpy(this->message,message,length);
}

LDAPMessage::LDAPMessage(LDAPProtocolOp* op, uint32_t id, int len){
    this->protocolOp = op;	
    this->appendVector(MESSAGE_TYPE);
    this->length = this->protocolOp->getLength() + 4 + len;
    this->appendVector(this->length);
    this->appendVector(2);
    this->appendVector(len);
    for(int i = 0; i < len; i++){
        this->appendVector((id>>((len-1-i)*8)) & 0xFF);
    }
    this->appendVector(this->protocolOp->getType());
    this->appendVector(this->protocolOp->getLength());
    this->appendVector(this->protocolOp->messVector);
}



void LDAPMessage::parseMessage(){
    if(int(this->message[0]) == 2){
        int idLen = int(this->message[1]);
        cout << "LEN:" << idLen << endl;
        if(idLen >= 1 && idLen <= 4){
            uint8_t* mess = new uint8_t[this->length];

            // Allocates space for 32bit int
            uint8_t* id = new uint8_t[sizeof(uint32_t)];
            memset(id,0,sizeof(uint32_t)*sizeof(uint8_t));

            for(int i = 0; i < idLen; i++){
                id[i] = this->message[2+idLen-i-1];
                cout << int(id[i]) << endl;
            }
  
            this->messageID = * (uint32_t*) id;
            this->IDLen = idLen;

            printf("%x\n", *id);
            cout << "ID: " << this->messageID << endl;

            int requestType = int(this->message[idLen+2]);
            int requestLength = int(this->message[idLen+3]);


            memcpy(mess,this->message+idLen+4,requestLength);
            this->protocolOp = new LDAPProtocolOp(requestLength,mess,requestType);
            this->protocolOp->parseRequest();
        }
    }
}
