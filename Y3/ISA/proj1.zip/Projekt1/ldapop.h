#ifndef __LDAPOP_H_INCLUDED__
#define __LDAPOP_H_INCLUDED__

#include <stdlib.h>
#include <vector>
#include <string.h>
#include <sstream>
#include <stack> 
//debug only
#include <iostream>

using namespace std;

class LDAPProtocolOp{
private:
    int length;
    uint8_t* message;
    char* password;
    int index;
    string substr;
    enum operation_t {BIND_REQUEST = 0x60, BIND_RESPONSE = 0x61, SEARCH_REQUEST = 0x63};
    enum state_t {START,SKIP,BASE,SCOPE,DEREF,SIZE,TIME,TYPES,FILTER};
    enum filter_t {AND=0xa0,OR=0xa1,NOT=0xa2,EQ=0xa3,SUB=0xa4};
    operation_t type;
    int version;
    
    struct fItem{
        filter_t type;
        string leftOp;
        string rightOp;
    };

    struct req{
        uint32_t size = 0;
        uint32_t time = 0;
        stack<fItem> *filter;
    } *reqStruct;
    
    bool parseInt(uint32_t&);
    bool parseString(string&);
    void createString(string&);
    bool parseSubString(string&);
    bool parseFilter();
    void incrementIndex();
    void incrementIndex(int);

public:
    class out_of_range : public exception
    {
        virtual const char* what() const throw(){
            return "Index out of range!";
        }
    } myex;
    vector<uint8_t> messVector;
    LDAPProtocolOp(int,uint8_t*,int);
    LDAPProtocolOp();
    void parseBindRequest();
    void parseSearchRequest();
    void parseRequest();
    LDAPProtocolOp createResponse();
    LDAPProtocolOp* processProtocolOp(string);
    void getMessage(uint8_t*&,int&);
    int getType();
    int getLength();
    void appendVector(uint8_t);
};

#endif