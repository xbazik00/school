#ifndef __LDAPMESS_H_INCLUDED__
#define __LDAPMESS_H_INCLUDED__

#include "ldapop.h"
#include <iostream>

#define MESSAGE_TYPE (0x30)

class LDAPMessage {
private:
    int length;
    uint32_t messageID;
    int IDLen;
    uint8_t* message;
public:
    vector<uint8_t> messVector;
    LDAPProtocolOp* protocolOp;
    LDAPMessage(int, uint8_t*);
    LDAPMessage(LDAPProtocolOp*,uint32_t,int);
    void parseMessage();
    void setMessage();
    void appendVector(uint8_t);
    void appendVector(vector<uint8_t>);
    int getLength();
    uint32_t getID();
    int getIDLength();
};

#endif
